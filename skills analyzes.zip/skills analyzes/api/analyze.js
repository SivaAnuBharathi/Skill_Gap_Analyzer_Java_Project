const roles = require('./roles.json');

const readiness = [
    {
        minimum: 80,
        level: 'Advanced',
        message: "Excellent! You're almost job-ready. Focus on the few remaining skills to become a strong candidate."
    },
    {
        minimum: 50,
        level: 'Intermediate',
        message: 'Good progress! You have a solid foundation. Dedicate time to learning the missing skills to stand out.'
    },
    {
        minimum: 25,
        level: 'Beginner',
        message: "You've made a start! There are several key skills to develop. Follow a structured learning path to build your expertise."
    },
    {
        minimum: 0,
        level: 'Getting Started',
        message: "This is a new field for you, but that's okay! Everyone starts somewhere. Follow the recommended resources to begin your journey."
    }
];

module.exports = function analyze(req, res) {
    if (req.method !== 'POST') {
        res.setHeader('Allow', 'POST');
        return res.status(405).json({ error: 'Method not allowed' });
    }

    const input = typeof req.body === 'string' ? parseBody(req.body) : req.body;
    if (!input || typeof input !== 'object' || Array.isArray(input)) {
        return res.status(400).json({ error: 'Request body must be a JSON object' });
    }

    const { name, age, education, desiredJob, currentSkills } = input;
    if ([name, education, desiredJob, currentSkills].some(value =>
        value !== undefined && typeof value !== 'string'
    ) || (age !== undefined && typeof age !== 'string' && typeof age !== 'number')) {
        return res.status(400).json({ error: 'Name, education, job, and skills must be strings; age must be a string or number' });
    }

    const role = roles[desiredJob];
    if (!role) {
        return res.status(400).json({ error: `Job role not found: ${desiredJob || ''}` });
    }

    const userSkills = String(currentSkills || '')
        .split(',')
        .map(skill => skill.trim().toLowerCase())
        .filter(Boolean);
    const matchedSkills = [];
    const missingSkills = [];

    for (const skill of role.allRequiredSkills) {
        const normalizedSkill = skill.toLowerCase();
        if (userSkills.some(userSkill =>
            normalizedSkill.includes(userSkill) || userSkill.includes(normalizedSkill)
        )) {
            matchedSkills.push(skill);
        } else {
            missingSkills.push(skill);
        }
    }

    const totalRequiredSkills = role.allRequiredSkills.length;
    const readinessPercent = totalRequiredSkills
        ? Math.floor((matchedSkills.length * 100) / totalRequiredSkills)
        : 0;
    const readinessStatus = readiness.find(status => readinessPercent >= status.minimum);
    const learningResources = role.learningResources.flatMap(resource => {
        if (!Array.isArray(resource.skills) || resource.skills.length === 0) {
            return [resource];
        }

        const relevantSkills = resource.skills.filter(skill => missingSkills.includes(skill));
        return relevantSkills.length ? [{ ...resource, skills: relevantSkills }] : [];
    });
    const estimatedWeeks = missingSkills.length * 3;
    const estimatedLearningTime = estimatedWeeks <= 4
        ? `${estimatedWeeks} weeks`
        : `${Math.floor(estimatedWeeks / 4)} - ${Math.floor(estimatedWeeks / 4) + 2} months`;

    return res.status(200).json({
        name: String(name || ''),
        age: String(age || ''),
        education: String(education || ''),
        desiredJob,
        category: role.category,
        readinessPercent,
        readinessLevel: readinessStatus.level,
        readinessMessage: readinessStatus.message,
        recommendedEducation: role.recommendedEducation,
        salaryRange: role.salaryRange,
        estimatedLearningTime,
        totalRequiredSkills,
        matchedSkillsCount: matchedSkills.length,
        missingSkillsCount: missingSkills.length,
        matchedSkills,
        missingSkills,
        allRequiredSkills: role.allRequiredSkills,
        learningResources
    });
};

function parseBody(body) {
    try {
        return JSON.parse(body);
    } catch (error) {
        return null;
    }
}

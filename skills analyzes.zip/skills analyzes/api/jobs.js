const roles = require('./roles.json');

module.exports = function jobs(req, res) {
    if (req.method !== 'GET') {
        res.setHeader('Allow', 'GET');
        return res.status(405).json({ error: 'Method not allowed' });
    }

    const categories = new Map();
    for (const [title, role] of Object.entries(roles)) {
        if (!categories.has(role.category)) {
            categories.set(role.category, []);
        }
        categories.get(role.category).push(title);
    }

    return res.status(200).json({
        categories: Array.from(categories, ([name, jobs]) => ({ name, jobs }))
    });
};

/**
 * SkillBridge — Career Intelligence & Skill Gap Analyser
 * Frontend Application & Multi-Page View Routing
 */

// ─── Configuration ───────────────────────────────────────────────────
const supabaseClient = typeof createSupabaseClient === 'function' ? createSupabaseClient() : null;
const API_BASE = window.location.origin;

let currentStep = 1;
let analysisData = null;
const assistantHistory = [];
let currentUser = null;
let isGuestMode = false;

// Common skills database for dynamic chips
const ROLE_SKILLS_MAP = {
    'Frontend Developer': ['HTML5', 'CSS3', 'JavaScript', 'React.js', 'TypeScript', 'Git', 'Responsive Design', 'REST APIs', 'Webpack/Vite', 'Tailwind CSS'],
    'Backend Developer': ['Java', 'Python', 'Node.js', 'SQL Databases', 'REST API Design', 'Docker', 'Git', 'Microservices', 'Linux/Unix', 'AWS'],
    'Full Stack Developer': ['JavaScript', 'React.js', 'Node.js', 'SQL & NoSQL', 'Git', 'Docker', 'REST APIs', 'TypeScript', 'HTML5/CSS3', 'CI/CD'],
    'Data Scientist': ['Python', 'SQL', 'Machine Learning', 'Statistics', 'Pandas/NumPy', 'Data Visualization', 'Deep Learning', 'Scikit-Learn', 'Tableau'],
    'AI Engineer': ['Python', 'Deep Learning', 'PyTorch/TensorFlow', 'LLMs & Prompt Engineering', 'LangChain', 'Docker', 'REST APIs', 'Git'],
    'DevOps Engineer': ['Linux Administration', 'Docker', 'Kubernetes', 'CI/CD Pipelines', 'AWS/GCP/Azure', 'Terraform', 'Git', 'Bash Scripting', 'Monitoring'],
    'UI/UX Designer': ['Figma', 'User Research', 'Wireframing', 'Prototyping', 'Design Systems', 'Usability Testing', 'Interaction Design', 'HTML/CSS Basics'],
    'Robotics Engineer': ['C++', 'Python', 'ROS/ROS2', 'Control Systems', 'Kinematics', 'Embedded Systems', 'Microcontrollers', 'Computer Vision'],
    'Mechanical Design Engineer': ['CAD Software (SolidWorks)', 'GD&T', 'FEA Analysis', 'Thermodynamics', 'Material Selection', 'Manufacturing Processes', 'DFM/DFA'],
    'Cybersecurity Analyst': ['Network Security', 'Vulnerability Assessment', 'SIEM Tools', 'Incident Response', 'Ethical Hacking', 'Firewalls', 'Linux/Windows Security']
};

const DEFAULT_POPULAR_SKILLS = ['JavaScript', 'Python', 'React.js', 'SQL', 'Git', 'HTML5', 'CSS3', 'Docker', 'Java', 'REST APIs', 'Linux', 'AWS', 'C++', 'Node.js'];

// Benchmark Database Cache
let cachedRolesDatabase = null;
let currentHistoryFilter = '';
window.__historyRecords = {};

async function fetchRolesDatabase() {
    if (cachedRolesDatabase) return cachedRolesDatabase;
    try {
        const res = await fetch('roles.json');
        if (res.ok) {
            cachedRolesDatabase = await res.json();
            return cachedRolesDatabase;
        }
    } catch (e) {
        console.warn('Could not load roles.json:', e);
    }
    return null;
}

function prefillUserData() {
    const nameField = document.getElementById('input-name');
    if (nameField && !nameField.value.trim() && currentUser) {
        nameField.value = currentUser.fullName || currentUser.name || (currentUser.email ? currentUser.email.split('@')[0] : '');
    }
}

// ─── App Initialization ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    // 0. Pre-fetch benchmark dataset
    fetchRolesDatabase();

    // 1. Check Authentication (Supabase Session or Guest Mode)
    await initAuth();

    // Auto pre-fill user profile fields
    prefillUserData();

    // 2. Setup Page View Navigation (Multi-page tabbed router)
    setupPageRouter();

    // 3. Load dynamic job roles from API
    loadJobRoles();

    // 4. Setup Skill input & interactive tags
    setupSkillTagsInput();
    updateQuickSkillChips(null);

    // 5. Setup AI Career Guide drawer
    setupAssistant();

    // 6. Setup mobile navigation toggle
    setupMobileNav();

    // 7. Load saved analyses from database
    loadSavedAnalyses();
    document.getElementById('refresh-saved-results')?.addEventListener('click', loadSavedAnalyses);
    document.getElementById('history-search-input')?.addEventListener('input', (e) => filterSavedAnalyses(e.target.value));
    document.getElementById('clear-all-history')?.addEventListener('click', clearAllHistory);
});

// ─── Authentication Management ───────────────────────────────────────
async function initAuth() {
    let authenticated = false;

    // 1. Check Active User Session (Local Account)
    const activeUserJson = sessionStorage.getItem('skillbridge_active_user') || localStorage.getItem('skillbridge_active_user');
    if (activeUserJson) {
        try {
            currentUser = JSON.parse(activeUserJson);
            isGuestMode = !!currentUser.isGuest;
            authenticated = true;
        } catch (e) {
            sessionStorage.removeItem('skillbridge_active_user');
            localStorage.removeItem('skillbridge_active_user');
        }
    }

    // 2. Check Guest Session fallback
    if (!authenticated) {
        const guestUserJson = sessionStorage.getItem('skillbridge_guest_user');
        if (guestUserJson) {
            try {
                currentUser = JSON.parse(guestUserJson);
                isGuestMode = true;
                authenticated = true;
            } catch (e) {
                sessionStorage.removeItem('skillbridge_guest_user');
            }
        }
    }

    // 3. Check Supabase Session if not already authenticated
    if (!authenticated && supabaseClient) {
        try {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (session) {
                currentUser = session.user;
                isGuestMode = false;
                authenticated = true;
            }
        } catch (e) {
            console.warn('Supabase auth session check failed:', e);
        }
    }

    // If not authenticated, redirect to signin page
    if (!authenticated) {
        window.location.replace('signin.html');
        return;
    }

    // Display user email / avatar in navbar
    const emailEl = document.getElementById('nav-user-email');
    const avatarEl = document.getElementById('user-avatar');
    if (emailEl && currentUser) {
        const displayName = currentUser.fullName || currentUser.email || 'Member';
        emailEl.textContent = isGuestMode ? `${displayName} (Guest)` : displayName;
        if (avatarEl) {
            avatarEl.textContent = displayName.charAt(0).toUpperCase();
        }
    }

    // Sign out button handler
    const signoutBtn = document.getElementById('btn-signout');
    if (signoutBtn) {
        signoutBtn.addEventListener('click', async () => {
            sessionStorage.removeItem('skillbridge_active_user');
            localStorage.removeItem('skillbridge_active_user');
            sessionStorage.removeItem('skillbridge_guest_user');
            if (supabaseClient && !isGuestMode) {
                try {
                    await supabaseClient.auth.signOut();
                } catch (e) {
                    console.warn('Signout error:', e);
                }
            }
            window.location.replace('signin.html');
        });
    }
}

// ─── Multi-Page Views Router (No Continuous Scrolling) ───────────────
function setupPageRouter() {
    // Global delegation for nav links and any anchor targeting a page view
    document.addEventListener('click', (e) => {
        const link = e.target.closest('[data-page], a[href^="#"]');
        if (!link) return;
        const pageId = link.getAttribute('data-page') || link.getAttribute('href')?.replace('#', '');
        const validPages = ['home', 'analyze', 'results', 'how-it-works', 'saved-analyses'];
        if (validPages.includes(pageId)) {
            e.preventDefault();
            navigateTo(pageId);
        }
    });

    // Logo click goes home
    document.getElementById('nav-logo')?.addEventListener('click', (e) => {
        e.preventDefault();
        navigateTo('home');
    });

    // Listen to browser hash changes (support back/forward buttons)
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.replace('#', '') || 'home';
        navigateTo(hash, false);
    });

    // Initial route from URL hash
    const initialHash = window.location.hash.replace('#', '') || 'home';
    navigateTo(initialHash, false);
}

function navigateTo(pageId, updateHash = true) {
    const validPages = ['home', 'analyze', 'results', 'how-it-works', 'saved-analyses'];
    if (!validPages.includes(pageId)) {
        pageId = 'home';
    }

    // 1. Hide all page views
    document.querySelectorAll('.page-view').forEach(view => {
        view.classList.remove('active');
    });

    // 2. Remove active class from all nav links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-page') === pageId) {
            link.classList.add('active');
        }
    });

    // 3. Show target view
    const targetView = document.getElementById(`page-${pageId}`);
    if (targetView) {
        targetView.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'instant' });
    }

    // 4. Update browser URL hash
    if (updateHash) {
        window.location.hash = pageId;
    }

    // 5. Special logic for Results view
    if (pageId === 'results') {
        const emptyCard = document.getElementById('empty-report-card');
        const reportContent = document.getElementById('active-report-content');
        if (analysisData) {
            if (emptyCard) emptyCard.style.display = 'none';
            if (reportContent) reportContent.style.display = 'block';
        } else {
            if (emptyCard) emptyCard.style.display = 'block';
            if (reportContent) reportContent.style.display = 'none';
        }
    }

    // 6. Refresh saved history whenever navigating to Saved Analyses
    if (pageId === 'saved-analyses') {
        loadSavedAnalyses();
    }

    // 7. Auto prefill candidate details on analyze page
    if (pageId === 'analyze') {
        prefillUserData();
    }

    // 8. Close mobile navigation if open
    const navLinks = document.getElementById('nav-links');
    if (navLinks) navLinks.classList.remove('mobile-open');
}

// ─── Mobile Navigation Toggle ────────────────────────────────────────
function setupMobileNav() {
    const toggleBtn = document.getElementById('nav-mobile-toggle');
    const navLinks = document.getElementById('nav-links');
    if (toggleBtn && navLinks) {
        toggleBtn.addEventListener('click', () => {
            navLinks.classList.toggle('mobile-open');
        });
    }
}

// ─── Quick Start Role from Home Page ─────────────────────────────────
function quickStartRole(roleName) {
    const jobSelect = document.getElementById('input-job');
    if (jobSelect) {
        jobSelect.value = roleName;
    }
    updateQuickSkillChips(roleName);
    navigateTo('analyze');

    // If step 1 name is already filled, jump to step 2
    const nameInput = document.getElementById('input-name');
    if (nameInput && nameInput.value.trim()) {
        nextStep(1);
    }
}

// ─── Load Job Roles from API ─────────────────────────────────────────
async function loadJobRoles() {
    const select = document.getElementById('input-job');
    if (!select) return;

    try {
        const response = await fetch(`${API_BASE}/api/jobs`);
        if (!response.ok) throw new Error('Failed to load job roles');

        const data = await response.json();
        select.innerHTML = '<option value="" disabled selected>Select your desired career role</option>';

        data.categories.forEach(category => {
            const optgroup = document.createElement('optgroup');
            optgroup.label = `── ${category.name} ──`;

            category.jobs.forEach(job => {
                const option = document.createElement('option');
                option.value = job;
                option.textContent = job;
                optgroup.appendChild(option);
            });

            select.appendChild(optgroup);
        });
    } catch (error) {
        console.warn('Using fallback role list:', error);
        loadFallbackJobRoles(select);
    }

    // Listen for role changes to update quick skill chips
    select.addEventListener('change', () => {
        updateQuickSkillChips(select.value);
    });
}

function loadFallbackJobRoles(select) {
    select.innerHTML = `
        <option value="" disabled selected>Select your desired career role</option>
        <optgroup label="── Software Development ──">
            <option value="Frontend Developer">Frontend Developer</option>
            <option value="Backend Developer">Backend Developer</option>
            <option value="Full Stack Developer">Full Stack Developer</option>
            <option value="Mobile App Developer">Mobile App Developer</option>
            <option value="DevOps Engineer">DevOps Engineer</option>
            <option value="QA Engineer">QA Engineer</option>
        </optgroup>
        <optgroup label="── Data & AI ──">
            <option value="Data Scientist">Data Scientist</option>
            <option value="Data Analyst">Data Analyst</option>
            <option value="ML Engineer">ML Engineer</option>
            <option value="AI Engineer">AI Engineer</option>
        </optgroup>
        <optgroup label="── Cybersecurity ──">
            <option value="Cybersecurity Analyst">Cybersecurity Analyst</option>
            <option value="Ethical Hacker">Ethical Hacker</option>
        </optgroup>
        <optgroup label="── Design & Product ──">
            <option value="UI/UX Designer">UI/UX Designer</option>
            <option value="Product Manager">Product Manager</option>
        </optgroup>
        <optgroup label="── Engineering Disciplines ──">
            <option value="Mechanical Design Engineer">Mechanical Design Engineer</option>
            <option value="Electrical Engineer">Electrical Engineer</option>
            <option value="Civil Engineer">Civil Engineer</option>
            <option value="Robotics Engineer">Robotics Engineer</option>
            <option value="Automotive Engineer">Automotive Engineer</option>
            <option value="Aerospace Engineer">Aerospace Engineer</option>
        </optgroup>
    `;
}

// ─── Quick-Add Skill Chips ───────────────────────────────────────────
function updateQuickSkillChips(roleName) {
    const list = document.getElementById('quick-skills-list');
    if (!list) return;

    list.innerHTML = '';
    const skillsToDisplay = (roleName && ROLE_SKILLS_MAP[roleName]) ? ROLE_SKILLS_MAP[roleName] : DEFAULT_POPULAR_SKILLS;
    const currentSkills = getCurrentSkillList();

    skillsToDisplay.forEach(skill => {
        const chip = document.createElement('button');
        chip.type = 'button';
        const isAdded = currentSkills.some(s => s.toLowerCase() === skill.toLowerCase());
        chip.className = `quick-skill-chip ${isAdded ? 'added' : ''}`;
        chip.innerHTML = `
            <span>${isAdded ? '✓' : '+'}</span>
            ${escapeHtml(skill)}
        `;

        chip.addEventListener('click', () => {
            toggleQuickSkill(skill, chip);
        });

        list.appendChild(chip);
    });
}

function toggleQuickSkill(skill, chipEl) {
    const textarea = document.getElementById('input-skills');
    const skills = getCurrentSkillList();
    const existingIndex = skills.findIndex(s => s.toLowerCase() === skill.toLowerCase());

    if (existingIndex >= 0) {
        skills.splice(existingIndex, 1);
        if (chipEl) {
            chipEl.classList.remove('added');
            chipEl.querySelector('span').textContent = '+';
        }
    } else {
        skills.push(skill);
        if (chipEl) {
            chipEl.classList.add('added');
            chipEl.querySelector('span').textContent = '✓';
        }
    }

    textarea.value = skills.join(', ');
    updateSkillTags();
}

function getCurrentSkillList() {
    const textarea = document.getElementById('input-skills');
    if (!textarea || !textarea.value.trim()) return [];
    return textarea.value.split(',').map(s => s.trim()).filter(Boolean);
}

// ─── Skill Tags Input with Removable Chips ───────────────────────────
function setupSkillTagsInput() {
    const textarea = document.getElementById('input-skills');
    if (!textarea) return;

    textarea.addEventListener('input', () => {
        updateSkillTags();
        const role = document.getElementById('input-job')?.value;
        updateQuickSkillChips(role);
    });
}

function updateSkillTags() {
    const tagsContainer = document.getElementById('skill-tags');
    if (!tagsContainer) return;

    const skills = getCurrentSkillList();
    tagsContainer.innerHTML = '';

    skills.forEach((skill, index) => {
        const tag = document.createElement('span');
        tag.className = 'skill-tag';
        tag.innerHTML = `
            <span>${escapeHtml(skill)}</span>
            <button class="tag-remove-btn" type="button" aria-label="Remove skill">&times;</button>
        `;

        tag.querySelector('.tag-remove-btn').addEventListener('click', () => {
            removeSkillAtIndex(index);
        });

        tagsContainer.appendChild(tag);
    });
}

function removeSkillAtIndex(index) {
    const skills = getCurrentSkillList();
    skills.splice(index, 1);
    const textarea = document.getElementById('input-skills');
    textarea.value = skills.join(', ');
    updateSkillTags();

    const role = document.getElementById('input-job')?.value;
    updateQuickSkillChips(role);
}

// ─── Multi-Step Form Logic ───────────────────────────────────────────
function nextStep(step) {
    if (!validateStep(step)) return;

    const currentStepEl = document.getElementById(`form-step-${step}`);
    const nextStepEl = document.getElementById(`form-step-${step + 1}`);

    if (currentStepEl && nextStepEl) {
        currentStepEl.classList.remove('active');
        nextStepEl.classList.add('active');
        currentStep = step + 1;
        updateProgressIndicator();
    }
}

function prevStep(step) {
    const currentStepEl = document.getElementById(`form-step-${step}`);
    const prevStepEl = document.getElementById(`form-step-${step - 1}`);

    if (currentStepEl && prevStepEl) {
        currentStepEl.classList.remove('active');
        prevStepEl.classList.add('active');
        currentStep = step - 1;
        updateProgressIndicator();
    }
}

function updateProgressIndicator() {
    for (let i = 1; i <= 3; i++) {
        const stepEl = document.getElementById(`prog-step-${i}`);
        const lineEl = document.getElementById(`prog-line-${i}`);

        if (stepEl) {
            if (i < currentStep) {
                stepEl.classList.remove('active');
                stepEl.classList.add('completed');
            } else if (i === currentStep) {
                stepEl.classList.add('active');
                stepEl.classList.remove('completed');
            } else {
                stepEl.classList.remove('active', 'completed');
            }
        }

        if (lineEl) {
            if (i < currentStep) {
                lineEl.classList.add('active');
            } else {
                lineEl.classList.remove('active');
            }
        }
    }
}

function validateStep(step) {
    let isValid = true;

    if (step === 1) {
        const name = document.getElementById('input-name');
        const age = document.getElementById('input-age');
        const education = document.getElementById('input-education');

        if (!name.value.trim()) {
            showFieldError(name, 'Please enter your full name');
            isValid = false;
        } else {
            clearFieldError(name);
        }

        const ageVal = parseInt(age.value);
        if (!age.value || isNaN(ageVal) || ageVal < 16 || ageVal > 80) {
            showFieldError(age, 'Please enter a valid age (16–80)');
            isValid = false;
        } else {
            clearFieldError(age);
        }

        if (!education.value) {
            showFieldError(education, 'Please select your highest education');
            isValid = false;
        } else {
            clearFieldError(education);
        }
    }

    if (step === 2) {
        const job = document.getElementById('input-job');
        if (!job.value) {
            showFieldError(job, 'Please choose a target career role');
            isValid = false;
        } else {
            clearFieldError(job);
        }
    }

    return isValid;
}

function showFieldError(input, message) {
    input.classList.add('error');
    let errorEl = input.closest('.form-group')?.querySelector('.form-error');
    if (!errorEl) {
        errorEl = document.createElement('p');
        errorEl.className = 'form-error show';
        input.closest('.input-wrapper')?.after(errorEl);
    }
    errorEl.textContent = message;
    errorEl.classList.add('show');

    input.addEventListener('focus', () => clearFieldError(input), { once: true });
}

function clearFieldError(input) {
    input.classList.remove('error');
    const errorEl = input.closest('.form-group')?.querySelector('.form-error');
    if (errorEl) {
        errorEl.classList.remove('show');
    }
}

// ─── Client-Side Gap Analysis Engine (Offline / Standalone Fallback) ──
async function performLocalSkillGapAnalysis(requestData) {
    const desiredJob = requestData.desiredJob;
    const db = await fetchRolesDatabase();
    let roleData = db ? db[desiredJob] : null;

    if (!roleData) {
        const fallbackSkills = ROLE_SKILLS_MAP[desiredJob] || DEFAULT_POPULAR_SKILLS.slice(0, 10);
        roleData = {
            desiredJob: desiredJob,
            category: 'Engineering & Technology',
            allRequiredSkills: fallbackSkills,
            recommendedEducation: "Bachelor's in CS/IT, Engineering or equivalent",
            salaryRange: "₹5,00,000 - ₹18,00,000 per year",
            learningResources: [
                { title: `${desiredJob} Mastery Roadmap`, url: "https://roadmap.sh", cost: "Free", level: "Beginner" },
                { title: "MDN Web & Technical Docs", url: "https://developer.mozilla.org", cost: "Free", level: "Beginner" },
                { title: "Hands-on Projects & Guided Practice", url: "https://freecodecamp.org", cost: "Free", level: "Intermediate" }
            ]
        };
    }

    const requiredSkills = roleData.allRequiredSkills || roleData.requiredSkills || roleData.missingSkills || [];
    const userSkillsRaw = (requestData.currentSkills || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

    const matchedSkills = [];
    const missingSkills = [];

    requiredSkills.forEach(reqSkill => {
        const reqLower = reqSkill.toLowerCase();
        const hasSkill = userSkillsRaw.some(u => {
            return reqLower.includes(u) || u.includes(reqLower) || reqLower.replace(/[^a-z0-9]/g, '') === u.replace(/[^a-z0-9]/g, '');
        });
        if (hasSkill) {
            matchedSkills.push(reqSkill);
        } else {
            missingSkills.push(reqSkill);
        }
    });

    const total = requiredSkills.length || 1;
    const readinessPercent = Math.round((matchedSkills.length * 100) / total);
    const readinessLevel = getReadinessLevel(readinessPercent);

    let readinessMessage = '';
    if (readinessPercent >= 80) {
        readinessMessage = "Outstanding! You possess the primary core competencies for this role. Refine the remaining skills to become a top-tier candidate.";
    } else if (readinessPercent >= 50) {
        readinessMessage = "Great progress! You have a solid foundation in key areas. Prioritize the missing competencies to become job ready.";
    } else if (readinessPercent >= 25) {
        readinessMessage = "Good start! You have introductory exposure. Follow the structured learning path below to close your skill gaps.";
    } else {
        readinessMessage = "Welcome to your new career journey! Every expert started here. Dive into the recommended resources to build your foundational skillset.";
    }

    const weeks = missingSkills.length * 3;
    const estimatedLearningTime = weeks <= 4 ? `${weeks} weeks` : `${Math.floor(weeks / 4)} - ${Math.floor(weeks / 4) + 2} months`;

    return {
        name: requestData.name,
        age: requestData.age,
        education: requestData.education,
        desiredJob: desiredJob,
        category: roleData.category || 'Engineering & Technology',
        readinessPercent: readinessPercent,
        readinessLevel: readinessLevel,
        readinessMessage: readinessMessage,
        recommendedEducation: roleData.recommendedEducation || "Bachelor's in CS/IT or equivalent",
        salaryRange: roleData.salaryRange || "₹5,00,000 - ₹18,00,000 per year",
        estimatedLearningTime: estimatedLearningTime,
        totalRequiredSkills: total,
        matchedSkillsCount: matchedSkills.length,
        missingSkillsCount: missingSkills.length,
        matchedSkills: matchedSkills,
        missingSkills: missingSkills,
        learningResources: roleData.learningResources || []
    };
}

// ─── Submit Assessment ────────────────────────────────────────────────
async function submitAnalysis() {
    if (!validateStep(2)) return;

    const form = document.getElementById('analysis-form');
    const progressIndicator = document.getElementById('form-progress');
    const loadingState = document.getElementById('loading-state');
    const progressBar = document.getElementById('loader-bar');
    const statusText = document.getElementById('loader-status-text');

    const requestData = {
        name: document.getElementById('input-name').value.trim() || currentUser?.fullName || (currentUser?.email ? currentUser.email.split('@')[0] : 'Candidate'),
        age: document.getElementById('input-age').value || '22',
        education: document.getElementById('input-education').value || "Bachelor's Degree",
        desiredJob: document.getElementById('input-job').value,
        currentSkills: document.getElementById('input-skills').value.trim()
    };

    // Show high-tech loading state
    form.style.display = 'none';
    progressIndicator.style.display = 'none';
    loadingState.style.display = 'block';

    // Cycling scanner messages
    const statuses = [
        'Analyzing candidate profile...',
        'Benchmarking against industry standards...',
        'Calculating readiness percentage...',
        'Synthesizing personalized learning roadmap...'
    ];
    let statusIdx = 0;
    const statusInterval = setInterval(() => {
        statusIdx = (statusIdx + 1) % statuses.length;
        if (statusText) statusText.textContent = statuses[statusIdx];
    }, 450);

    let progress = 10;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 16;
        if (progress > 90) progress = 90;
        progressBar.style.width = progress + '%';
    }, 180);

    let resultData = null;

    // 1. Try server API endpoint
    try {
        const response = await fetch(`${API_BASE}/api/analyze`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });
        if (response.ok) {
            resultData = await response.json();
        }
    } catch (e) {
        console.warn('Backend /api/analyze not available or static host; falling back to client-side engine:', e);
    }

    // 2. Client-side fallback if server not available (e.g. python http.server or offline)
    if (!resultData || resultData.error) {
        resultData = await performLocalSkillGapAnalysis(requestData);
    }

    analysisData = resultData;

    // 3. Construct persistent history record
    const skillsArr = requestData.currentSkills.split(',').map(s => s.trim()).filter(Boolean);
    const historyRecord = {
        id: 'rec_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        desired_job: analysisData.desiredJob,
        education: requestData.education,
        age: requestData.age,
        user_name: requestData.name,
        user_email: currentUser?.email || '',
        current_skills: skillsArr,
        matched_skills: analysisData.matchedSkills || [],
        missing_skills: analysisData.missingSkills || [],
        readiness_percent: analysisData.readinessPercent ?? 0,
        readiness_level: analysisData.readinessLevel || getReadinessLevel(analysisData.readinessPercent ?? 0),
        readiness_message: analysisData.readinessMessage || '',
        salary_range: analysisData.salaryRange || 'Market Standard',
        estimated_learning_time: analysisData.estimatedLearningTime || '2 - 4 Months',
        learning_pathway: analysisData.learningResources || analysisData.learningPathway || [],
        created_at: new Date().toISOString(),
        source: 'local'
    };

    // 4. Save to persistent local storage for the user
    saveLocalAnalysis(historyRecord);

    // 5. Also save to Java server storage if available
    try {
        await fetch(`${API_BASE}/api/history`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(historyRecord)
        });
    } catch (e) {}

    // 6. Also sync to Supabase if authenticated
    if (supabaseClient && !isGuestMode) {
        try {
            const { data: { user } } = await supabaseClient.auth.getUser();
            if (user) {
                await supabaseClient.from("learning_history").insert({
                    user_id: user.id,
                    user_name: historyRecord.user_name,
                    user_email: user.email,
                    course_name: historyRecord.desired_job,
                    career_goal: historyRecord.desired_job,
                    education: historyRecord.education,
                    current_skills: historyRecord.current_skills,
                    matched_skills: historyRecord.matched_skills,
                    missing_skills: historyRecord.missing_skills,
                    readiness_percent: historyRecord.readiness_percent,
                    readiness_level: historyRecord.readiness_level,
                    learning_pathway: historyRecord.learning_pathway,
                    progress_percent: 0,
                    status: "Completed"
                });
            }
        } catch (saveErr) {
            console.warn("Could not save to Supabase:", saveErr.message);
        }
    }

    // Refresh history cache in background
    loadSavedAnalyses();

    // Finish progress bar
    clearInterval(progressInterval);
    clearInterval(statusInterval);
    progressBar.style.width = '100%';

    setTimeout(() => {
        loadingState.style.display = 'none';
        form.style.display = 'block';
        progressIndicator.style.display = 'flex';

        // Show active report badge in navbar
        const reportBadge = document.getElementById('report-badge-dot');
        if (reportBadge) reportBadge.style.display = 'inline-block';

        // Display results & switch to results view
        displayResults(analysisData);
        navigateTo('results');
        showToast('Assessment complete! Saved to your history.', 'success');
    }, 450);
}

// ─── Display Results in My Report View ───────────────────────────────
function displayResults(data) {
    if (!data) return;

    // Show report container, hide empty card
    document.getElementById('empty-report-card').style.display = 'none';
    document.getElementById('active-report-content').style.display = 'block';

    // Subtitle
    const candidateName = data.name || (currentUser?.email ? currentUser.email.split('@')[0] : 'Candidate');
    document.getElementById('results-subtitle').textContent =
        `Personalized evaluation for ${candidateName} — Target: ${data.desiredJob}`;

    // Readiness Gauge & Score
    document.getElementById('readiness-score').textContent = data.readinessPercent + '%';
    const levelBadge = document.getElementById('readiness-level');
    levelBadge.textContent = data.readinessLevel;

    // Badge color
    if (data.readinessPercent >= 80) {
        levelBadge.style.background = 'rgba(52, 211, 153, 0.16)';
        levelBadge.style.color = '#34d399';
    } else if (data.readinessPercent >= 50) {
        levelBadge.style.background = 'rgba(129, 140, 248, 0.16)';
        levelBadge.style.color = '#818cf8';
    } else if (data.readinessPercent >= 25) {
        levelBadge.style.background = 'rgba(251, 191, 36, 0.16)';
        levelBadge.style.color = '#fbbf24';
    } else {
        levelBadge.style.background = 'rgba(248, 113, 113, 0.16)';
        levelBadge.style.color = '#f87171';
    }

    // Animate radial SVG progress circle
    const radialCircle = document.getElementById('radial-circle');
    if (radialCircle) {
        const circumference = 2 * Math.PI * 42;
        const offset = circumference - (data.readinessPercent / 100) * circumference;
        radialCircle.style.transition = 'stroke-dashoffset 1.4s cubic-bezier(0.16, 1, 0.3, 1)';
        radialCircle.style.strokeDashoffset = offset;
    }

    // Metric Counts
    animateNumber('matched-count', data.matchedSkillsCount, 600);
    animateNumber('missing-count', data.missingSkillsCount, 600);

    const totalReq = (data.matchedSkillsCount || 0) + (data.missingSkillsCount || 0);
    document.getElementById('matched-sub').textContent = `of ${data.totalRequiredSkills || totalReq} required`;
    document.getElementById('missing-sub').textContent = `skills to acquire`;
    document.getElementById('learning-time').textContent = data.estimatedLearningTime || '2 - 4 Months';

    // Guidance Message
    document.getElementById('readiness-message').textContent = data.readinessMessage ||
        'Focus on the foundational missing skills first to accelerate your career readiness.';

    // Career Details
    document.getElementById('salary-range').textContent = data.salaryRange || 'Competitive Market Rate';
    document.getElementById('rec-education').textContent = data.recommendedEducation || 'Degree or Portfolio';
    document.getElementById('job-category').textContent = data.category || 'Technology';

    // Matched Skills List
    const matchedList = document.getElementById('matched-skills-list');
    matchedList.innerHTML = '';
    document.getElementById('matched-panel-count').textContent = data.matchedSkillsCount || data.matchedSkills.length;

    if (!data.matchedSkills || data.matchedSkills.length === 0) {
        matchedList.innerHTML = '<p style="color: var(--text-muted); font-size: 0.88rem; padding: 12px 0;">No matched skills yet. Start with foundational skills below!</p>';
    } else {
        data.matchedSkills.forEach(skill => {
            const item = document.createElement('div');
            item.className = 'skill-item matched';
            item.innerHTML = `
                <svg class="skill-icon" viewBox="0 0 18 18" fill="none">
                    <path d="M9 1.5C4.86 1.5 1.5 4.86 1.5 9s3.36 7.5 7.5 7.5 7.5-3.36 7.5-7.5S13.14 1.5 9 1.5zm-1.5 10.94L4.56 9.5l1.06-1.06 1.88 1.88 4.88-4.88 1.06 1.06-5.94 5.94z" fill="currentColor"/>
                </svg>
                <span>${escapeHtml(skill)}</span>
            `;
            matchedList.appendChild(item);
        });
    }

    // Missing Skills List
    const missingList = document.getElementById('missing-skills-list');
    missingList.innerHTML = '';
    document.getElementById('missing-panel-count').textContent = data.missingSkillsCount || data.missingSkills.length;

    if (!data.missingSkills || data.missingSkills.length === 0) {
        missingList.innerHTML = '<p style="color: #34d399; font-size: 0.88rem; padding: 12px 0;">Outstanding! You have all the primary required skills for this role.</p>';
    } else {
        data.missingSkills.forEach(skill => {
            const item = document.createElement('div');
            item.className = 'skill-item missing';
            item.innerHTML = `
                <svg class="skill-icon" viewBox="0 0 18 18" fill="none">
                    <circle cx="9" cy="9" r="7" stroke="currentColor" stroke-width="1.5" fill="none"/>
                    <circle cx="9" cy="9" r="2.5" fill="currentColor"/>
                </svg>
                <span>${escapeHtml(skill)}</span>
            `;
            missingList.appendChild(item);
        });
    }

    // Render Interactive Study Progress Tracker
    renderStudyProgressTracker(data);

    // Learning Resources Grid
    const resourcesGrid = document.getElementById('resources-grid');
    resourcesGrid.innerHTML = '';

    const resources = data.learningResources || [];
    if (resources.length === 0) {
        resourcesGrid.innerHTML = '<p class="section-desc">You are already well-equipped for this career track!</p>';
    } else {
        resources.forEach(res => {
            const card = document.createElement('div');
            card.className = 'resource-card';
            const costClass = res.cost && res.cost.toLowerCase().includes('free') ? 'badge-free' : 'badge-paid';
            card.innerHTML = `
                <div class="resource-card-header">
                    <h4>${escapeHtml(res.title)}</h4>
                </div>
                <div class="resource-badges">
                    <span class="resource-badge ${costClass}">${escapeHtml(res.cost || 'Free')}</span>
                    <span class="resource-badge badge-level">${escapeHtml(res.level || 'All Levels')}</span>
                </div>
                <a href="${escapeHtml(res.url)}" target="_blank" rel="noopener noreferrer" class="resource-link">
                    Start Learning
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M4 10L10 4M10 4H5M10 4V9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </a>
            `;
            resourcesGrid.appendChild(card);
        });
    }
}

// ─── Interactive Study Progress Tracker Logic ─────────────────────────
function getStudyTrackerStorageKey(jobRole) {
    const userKey = getUserStorageKey();
    const cleanRole = (jobRole || 'general').toLowerCase().replace(/[^a-z0-9]/g, '_');
    return `skillbridge_study_${userKey}_${cleanRole}`;
}

function getSavedStudyProgress(jobRole) {
    try {
        const raw = localStorage.getItem(getStudyTrackerStorageKey(jobRole));
        return raw ? JSON.parse(raw) : [];
    } catch {
        return [];
    }
}

function saveStudyProgress(jobRole, completedSkills) {
    try {
        localStorage.setItem(getStudyTrackerStorageKey(jobRole), JSON.stringify(completedSkills));
    } catch (e) {
        console.warn('Error saving study progress:', e);
    }
}

function renderStudyProgressTracker(data) {
    const container = document.getElementById('study-tracker-section');
    const grid = document.getElementById('study-checklist-grid');
    if (!container || !grid) return;

    const missingSkills = data.missingSkills || [];
    if (missingSkills.length === 0) {
        container.style.display = 'none';
        return;
    }
    container.style.display = 'block';

    const completedSkills = new Set(getSavedStudyProgress(data.desiredJob));
    grid.innerHTML = '';

    missingSkills.forEach(skill => {
        const isDone = completedSkills.has(skill);
        const card = document.createElement('div');
        card.className = `study-item-card ${isDone ? 'completed' : ''}`;
        card.setAttribute('data-skill', skill);
        card.onclick = () => toggleStudySkill(skill, data);

        card.innerHTML = `
            <div class="study-item-checkbox">
                ${isDone ? `
                    <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                        <path d="M3 8.5l3.5 3.5 6.5-7" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                ` : ''}
            </div>
            <div class="study-item-content">
                <div class="study-item-name">${escapeHtml(skill)}</div>
                <div class="study-item-meta">
                    <span class="study-item-tag">${isDone ? '✓ Mastered' : 'Pending Study'}</span>
                    <span>Click to ${isDone ? 'unmark' : 'mark complete'}</span>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });

    updateStudyProgressUI(data, completedSkills);
}

function toggleStudySkill(skill, data) {
    const saved = new Set(getSavedStudyProgress(data.desiredJob));
    if (saved.has(skill)) {
        saved.delete(skill);
    } else {
        saved.add(skill);
    }
    saveStudyProgress(data.desiredJob, Array.from(saved));
    renderStudyProgressTracker(data);

    // Audio-visual feedback
    if (saved.has(skill)) {
        showToast(`Great work! You've mastered: ${skill}`, 'success');
    }
}

function selectAllStudySkills(markAll) {
    if (!analysisData) return;
    const missing = analysisData.missingSkills || [];
    const saved = markAll ? missing : [];
    saveStudyProgress(analysisData.desiredJob, saved);
    renderStudyProgressTracker(analysisData);
    if (markAll) {
        showToast('All skills marked as mastered! 🚀', 'success');
    }
}

function updateStudyProgressUI(data, completedSet) {
    const totalMissing = (data.missingSkills || []).length;
    const completedCount = completedSet.size;
    const pct = totalMissing > 0 ? Math.round((completedCount / totalMissing) * 100) : 100;

    // Update count labels
    const countEl = document.getElementById('tracker-completed-count');
    if (countEl) countEl.textContent = `${completedCount} / ${totalMissing}`;

    const rateEl = document.getElementById('tracker-completion-rate');
    if (rateEl) rateEl.textContent = `${pct}%`;

    const pctTextEl = document.getElementById('study-bar-pct-text');
    if (pctTextEl) pctTextEl.textContent = `${pct}% Completed`;

    // Update progress bar
    const fillEl = document.getElementById('study-progress-fill');
    if (fillEl) fillEl.style.width = `${pct}%`;

    // Projected Readiness Score calculation
    const baseScore = data.readinessPercent || 0;
    const maxBoost = 100 - baseScore;
    const boostEarned = Math.round((completedCount / (totalMissing || 1)) * maxBoost);
    const projectedTotal = Math.min(100, baseScore + boostEarned);

    const projectedText = document.getElementById('projected-readiness-text');
    if (projectedText) {
        projectedText.textContent = `${projectedTotal}% (${baseScore}% + ${boostEarned}% study gain)`;
    }
}

// ─── Retake / Reset Assessment ────────────────────────────────────────
function resetAnalysis() {
    currentStep = 1;
    updateProgressIndicator();

    document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
    document.getElementById('form-step-1')?.classList.add('active');

    navigateTo('analyze');
}

// ─── Local Assessment History Storage ────────────────────────────────
function getUserStorageKey() {
    // Priority: email > id > fallback 'local'
    // This ensures every signed-in user has their OWN history bucket
    const key = currentUser?.email || currentUser?.id || null;
    if (!key) return 'skillbridge_history_local';
    // Sanitize key (remove special chars)
    return 'skillbridge_history_' + key.replace(/[^a-zA-Z0-9@._-]/g, '_');
}

function getLocalAnalyses() {
    try {
        const key = getUserStorageKey();
        const raw = localStorage.getItem(key);
        let items = raw ? JSON.parse(raw) : [];

        // If user is logged in but hasn't run any tests under their email yet, check guest bucket
        if (items.length === 0 && key !== 'skillbridge_history_local') {
            const guestRaw = localStorage.getItem('skillbridge_history_local');
            if (guestRaw) {
                const guestItems = JSON.parse(guestRaw);
                if (Array.isArray(guestItems) && guestItems.length > 0) {
                    items = items.concat(guestItems);
                }
            }
        }
        return Array.isArray(items) ? items : [];
    } catch {
        return [];
    }
}

function saveLocalAnalysis(item) {
    try {
        const key = getUserStorageKey();
        const list = getLocalAnalyses();
        const filtered = list.filter(r => String(r.id) !== String(item.id));
        filtered.unshift(item);
        const trimmed = filtered.slice(0, 50);
        localStorage.setItem(key, JSON.stringify(trimmed));

        // Also ensure fallback local key is updated
        if (key !== 'skillbridge_history_local') {
            localStorage.setItem('skillbridge_history_local', JSON.stringify(trimmed));
        }
    } catch (e) {
        console.warn('[History] Could not save locally:', e);
    }
}

// ─── Saved Analyses History ───────────────────────────────────────────
async function loadSavedAnalyses() {
    const list = document.getElementById('saved-results-list');
    if (!list) return;

    list.innerHTML = `
        <div style="grid-column:1/-1; text-align:center; padding:36px 20px; color:var(--text-muted);">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" style="margin-bottom:12px; opacity:0.6; animation: spin 1.2s linear infinite;">
                <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" stroke-dasharray="32" fill="none"/>
            </svg>
            <p style="font-weight:600;">Loading your assessment history…</p>
        </div>`;

    // 1. Local browser storage
    const localItems = getLocalAnalyses();

    // 2. Local Java server storage (/api/history)
    let serverItems = [];
    try {
        const sRes = await fetch(`${API_BASE}/api/history`);
        if (sRes.ok) {
            const data = await sRes.json();
            if (Array.isArray(data)) {
                serverItems = data;
            }
        }
    } catch (e) {}

    // 3. Supabase Cloud storage
    let remoteItems = [];
    if (supabaseClient && !isGuestMode) {
        try {
            const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
            if (!authError && user) {
                const { data, error } = await supabaseClient
                    .from('learning_history')
                    .select('*')
                    .eq('user_id', user.id)
                    .order('created_at', { ascending: false })
                    .limit(50);

                if (!error && data) {
                    remoteItems = data.map(r => ({
                        id: r.id,
                        desired_job: r.career_goal || r.course_name || 'Career Assessment',
                        education: r.education || '',
                        current_skills: r.current_skills || [],
                        matched_skills: r.matched_skills || [],
                        missing_skills: r.missing_skills || [],
                        readiness_percent: r.readiness_percent ?? 0,
                        readiness_level: r.readiness_level || getReadinessLevel(r.readiness_percent ?? 0),
                        learning_pathway: r.learning_pathway || [],
                        user_name: r.user_name || '',
                        user_email: r.user_email || '',
                        created_at: r.created_at,
                        source: 'cloud'
                    }));
                }
            }
        } catch (e) {
            console.warn('Could not fetch Supabase history:', e);
        }
    }

    // 4. Merge items
    const mergedMap = new Map();
    localItems.forEach(l => mergedMap.set(String(l.id), { ...l, source: l.source || 'local' }));
    serverItems.forEach(s => {
        if (!mergedMap.has(String(s.id))) {
            mergedMap.set(String(s.id), { ...s, source: 'server' });
        }
    });
    remoteItems.forEach(r => {
        mergedMap.set(String(r.id), r);
    });

    const allItems = [...mergedMap.values()].sort((a, b) =>
        new Date(b.created_at || 0) - new Date(a.created_at || 0)
    );

    // Global cache for instant report retrieval without escaping issues
    window.__historyRecords = {};
    allItems.forEach(item => {
        window.__historyRecords[String(item.id)] = item;
    });

    renderSavedAnalyses(allItems);
}

function filterSavedAnalyses(query) {
    currentHistoryFilter = (query || '').trim().toLowerCase();
    const all = Object.values(window.__historyRecords || {});
    renderSavedAnalyses(all);
}

function renderSavedAnalyses(allItems) {
    const list = document.getElementById('saved-results-list');
    if (!list) return;

    let itemsToDisplay = allItems;
    if (currentHistoryFilter) {
        itemsToDisplay = allItems.filter(item => {
            const job = (item.desired_job || '').toLowerCase();
            const edu = (item.education || '').toLowerCase();
            const user = (item.user_name || '').toLowerCase();
            const skills = (item.matched_skills || []).concat(item.missing_skills || []).join(' ').toLowerCase();
            return job.includes(currentHistoryFilter) || edu.includes(currentHistoryFilter) || user.includes(currentHistoryFilter) || skills.includes(currentHistoryFilter);
        });
    }

    if (itemsToDisplay.length === 0) {
        if (allItems.length === 0) {
            list.innerHTML = `
                <div style="grid-column:1/-1; text-align:center; padding:52px 20px;">
                    <div style="font-size:3.5rem; margin-bottom:16px;">📊</div>
                    <h3 style="font-size:1.25rem; font-weight:700; margin-bottom:8px;">No Saved Analyses Yet</h3>
                    <p class="saved-empty-text" style="max-width:440px; margin:0 auto 24px;">Take your first skills gap assessment to benchmark your skills, calculate your readiness score, and track your career growth over time!</p>
                    <button class="btn btn-primary" onclick="navigateTo('analyze')" style="margin-top:4px;">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style="margin-right:6px;">
                            <path d="M8 1v14M1 8h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        Start Your First Assessment
                    </button>
                </div>`;
        } else {
            list.innerHTML = `
                <div style="grid-column:1/-1; text-align:center; padding:48px 20px; color:var(--text-muted);">
                    <div style="font-size:2.5rem; margin-bottom:12px;">🔍</div>
                    <p style="font-size:1rem; font-weight:600;">No analyses match "${escapeHtml(currentHistoryFilter)}"</p>
                    <button class="btn btn-outline" onclick="document.getElementById('history-search-input').value=''; filterSavedAnalyses('');" style="margin-top:12px;">Clear Search Filter</button>
                </div>`;
        }
        return;
    }

    list.innerHTML = '';

    // Summary Stats Banner
    const avgReadiness = Math.round(itemsToDisplay.reduce((s, i) => s + (i.readiness_percent || 0), 0) / itemsToDisplay.length);
    const bestScore = Math.max(...itemsToDisplay.map(i => i.readiness_percent || 0));
    const summaryBanner = document.createElement('div');
    summaryBanner.style.cssText = 'grid-column:1/-1; display:flex; gap:16px; flex-wrap:wrap; margin-bottom:12px;';
    summaryBanner.innerHTML = `
        <div class="saved-stat-chip">
            <span style="font-size:1.4rem; font-weight:800; color:var(--accent-indigo);">${itemsToDisplay.length}</span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Analyses Saved</span>
        </div>
        <div class="saved-stat-chip">
            <span style="font-size:1.4rem; font-weight:800; color:var(--accent-indigo);">${avgReadiness}%</span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Avg Readiness</span>
        </div>
        <div class="saved-stat-chip">
            <span style="font-size:1.4rem; font-weight:800; color:#059669;">${bestScore}%</span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">Top Score</span>
        </div>
        <div class="saved-stat-chip">
            <span style="font-size:1.4rem; font-weight:800; color:var(--accent-purple);">${isGuestMode ? '💾 Local' : '☁️ Synced'}</span>
            <span style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">${isGuestMode ? 'Saved in Browser' : 'Account Connected'}</span>
        </div>`;
    list.appendChild(summaryBanner);

    itemsToDisplay.forEach((item, idx) => {
        let date = 'Recently';
        try {
            date = new Intl.DateTimeFormat('en-IN', {
                timeZone: 'Asia/Kolkata',
                day: '2-digit', month: 'short', year: 'numeric',
                hour: '2-digit', minute: '2-digit', hour12: true
            }).format(new Date(item.created_at || Date.now()));
        } catch (e) {}

        const pct = Math.min(100, Math.max(0, item.readiness_percent || 0));
        let badgeColor = '#4f46e5';
        let bgColor = 'rgba(79,70,229,0.10)';
        let levelLabel = item.readiness_level || getReadinessLevel(pct);

        if (pct >= 80) {
            badgeColor = '#059669'; bgColor = 'rgba(5,150,105,0.10)';
        } else if (pct >= 50) {
            badgeColor = '#4f46e5'; bgColor = 'rgba(79,70,229,0.10)';
        } else if (pct >= 25) {
            badgeColor = '#d97706'; bgColor = 'rgba(217,119,6,0.10)';
        } else {
            badgeColor = '#dc2626'; bgColor = 'rgba(220,38,38,0.10)';
        }

        const matchedCount = (item.matched_skills || []).length;
        const missingCount = (item.missing_skills || []).length;

        let badgeTag = `<span style="font-size:0.7rem; background:rgba(99,102,241,0.08); color:var(--accent-indigo); border:1px solid rgba(99,102,241,0.2); padding:2px 8px; border-radius:999px;">💾 Saved</span>`;
        if (item.source === 'cloud') {
            badgeTag = `<span style="font-size:0.7rem; background:rgba(79,70,229,0.1); color:#4f46e5; border:1px solid rgba(79,70,229,0.25); padding:2px 8px; border-radius:999px;">☁️ Cloud</span>`;
        }

        const card = document.createElement('div');
        card.className = 'saved-analysis-card';
        card.id = `history-card-${item.id}`;
        card.style.cssText = 'cursor:pointer; animation: fadeInUp 0.35s ease both;';
        card.style.animationDelay = `${idx * 40}ms`;

        card.innerHTML = `
            <div class="saved-card-header">
                <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                    <h4 class="saved-card-job" style="font-size:1.05rem; font-weight:700;">${escapeHtml(item.desired_job || 'Career Role')}</h4>
                    ${badgeTag}
                </div>
                <span class="saved-card-date" style="font-size:0.78rem; color:var(--text-muted);">${date}</span>
            </div>

            <div style="display:flex; align-items:center; gap:14px; margin:14px 0;">
                <div style="position:relative; width:58px; height:58px; flex-shrink:0;">
                    <svg viewBox="0 0 60 60" style="width:100%; height:100%; transform:rotate(-90deg);">
                        <circle cx="30" cy="30" r="24" stroke="rgba(0,0,0,0.07)" stroke-width="6" fill="none"/>
                        <circle cx="30" cy="30" r="24" stroke="${badgeColor}" stroke-width="6" fill="none"
                            stroke-dasharray="${2 * Math.PI * 24}"
                            stroke-dashoffset="${2 * Math.PI * 24 * (1 - pct / 100)}"
                            stroke-linecap="round"/>
                    </svg>
                    <span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:0.75rem;font-weight:800;color:${badgeColor};">${pct}%</span>
                </div>
                <div style="flex:1; min-width:0;">
                    <div style="display:flex; align-items:center; gap:8px; margin-bottom:6px; flex-wrap:wrap;">
                        <span style="font-size:1.15rem; font-weight:800; color:${badgeColor};">${pct}% Readiness</span>
                        <span style="font-size:0.75rem; font-weight:600; background:${bgColor}; color:${badgeColor}; border:1px solid ${badgeColor}33; padding:2px 10px; border-radius:999px;">${levelLabel}</span>
                    </div>
                    <div style="display:flex; gap:12px; font-size:0.8rem; color:var(--text-secondary); flex-wrap:wrap;">
                        <span style="color:#059669; font-weight:600;">✓ ${matchedCount} matched</span>
                        <span style="color:#d97706; font-weight:600;">✗ ${missingCount} missing</span>
                        ${item.education ? `<span style="color:var(--text-muted);">🎓 ${escapeHtml(item.education)}</span>` : ''}
                    </div>
                </div>
            </div>

            ${item.matched_skills && item.matched_skills.length > 0 ? `
            <div style="margin-bottom:8px;">
                <div style="font-size:0.72rem; font-weight:700; color:#059669; text-transform:uppercase; letter-spacing:0.04em; margin-bottom:4px;">Matched Skills</div>
                <div style="display:flex; flex-wrap:wrap; gap:4px;">
                    ${item.matched_skills.slice(0, 5).map(s => `<span style="font-size:0.72rem; background:rgba(5,150,105,0.08); color:#059669; border:1px solid rgba(5,150,105,0.2); padding:2px 8px; border-radius:999px;">✓ ${escapeHtml(s)}</span>`).join('')}
                    ${item.matched_skills.length > 5 ? `<span style="font-size:0.72rem; color:var(--text-muted); align-self:center;">+${item.matched_skills.length - 5} more</span>` : ''}
                </div>
            </div>` : ''}

            ${item.missing_skills && item.missing_skills.length > 0 ? `
            <div style="margin-bottom:12px;">
                <div style="font-size:0.72rem; font-weight:700; color:#d97706; text-transform:uppercase; letter-spacing:0.04em; margin-bottom:4px;">Skills to Learn</div>
                <div style="display:flex; flex-wrap:wrap; gap:4px;">
                    ${item.missing_skills.slice(0, 5).map(s => `<span style="font-size:0.72rem; background:rgba(217,119,6,0.08); color:#d97706; border:1px solid rgba(217,119,6,0.2); padding:2px 8px; border-radius:999px;">✗ ${escapeHtml(s)}</span>`).join('')}
                    ${item.missing_skills.length > 5 ? `<span style="font-size:0.72rem; color:var(--text-muted); align-self:center;">+${item.missing_skills.length - 5} more</span>` : ''}
                </div>
            </div>` : ''}

            <div style="display:flex; justify-content:space-between; align-items:center; padding-top:12px; border-top:1px solid var(--border-primary); margin-top:auto;">
                <div style="display:flex; gap:8px;">
                    <button class="btn btn-primary" style="padding:7px 16px; font-size:0.8rem;" type="button" onclick="event.stopPropagation(); viewHistoryReportById('${escapeHtml(String(item.id))}');">
                        View Full Report →
                    </button>
                    <button class="btn btn-outline" style="padding:7px 12px; font-size:0.8rem; color:#ef4444;" type="button" title="Delete this assessment" onclick="event.stopPropagation(); deleteHistoryRecord('${escapeHtml(String(item.id))}');">
                        🗑
                    </button>
                </div>
                <span style="font-size:0.74rem; font-weight:600; color:var(--text-muted);">#${itemsToDisplay.length - idx}</span>
            </div>`;

        card.addEventListener('click', () => viewHistoryReportById(String(item.id)));
        list.appendChild(card);
    });
}

function viewHistoryReportById(id) {
    const record = window.__historyRecords ? window.__historyRecords[String(id)] : null;
    if (!record) {
        showToast('Assessment record not found', 'error');
        return;
    }
    loadPastAnalysisToReport(record);
}

function loadPastAnalysisToReport(record) {
    analysisData = {
        name: record.user_name || currentUser?.fullName || (currentUser?.email ? currentUser.email.split('@')[0] : 'Candidate'),
        desiredJob: record.desired_job,
        readinessPercent: record.readiness_percent ?? 0,
        readinessLevel: record.readiness_level || getReadinessLevel(record.readiness_percent ?? 0),
        matchedSkills: record.matched_skills || [],
        matchedSkillsCount: (record.matched_skills || []).length,
        missingSkills: record.missing_skills || [],
        missingSkillsCount: (record.missing_skills || []).length,
        totalRequiredSkills: ((record.matched_skills || []).length + (record.missing_skills || []).length),
        estimatedLearningTime: record.estimated_learning_time || '2 - 4 Months',
        readinessMessage: record.readiness_message || `Saved report from ${new Date(record.created_at || Date.now()).toLocaleDateString('en-IN')} — ${record.desired_job}.`,
        salaryRange: record.salary_range || 'Market Standard',
        recommendedEducation: record.education || 'Bachelor\'s Degree or equivalent',
        category: record.category || 'Engineering & Technology',
        learningResources: Array.isArray(record.learning_pathway) ? record.learning_pathway : []
    };

    displayResults(analysisData);
    navigateTo('results');
    showToast(`Loaded assessment report for "${record.desired_job}"`, 'success');
}

// Inline fallback
function loadAndViewReport(jsonStr) {
    try {
        const record = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
        loadPastAnalysisToReport(record);
    } catch (e) {
        console.error('Could not parse history record:', e);
    }
}

function getReadinessLevel(pct) {
    if (pct >= 80) return 'Job Ready';
    if (pct >= 60) return 'Proficient';
    if (pct >= 40) return 'Progressing';
    if (pct >= 20) return 'Developing';
    return 'Beginner';
}

async function deleteHistoryRecord(id) {
    if (!confirm('Remove this assessment from your history?')) return;

    // 1. Remove from localStorage
    try {
        const key = getUserStorageKey();
        const local = JSON.parse(localStorage.getItem(key) || '[]');
        const filtered = local.filter(r => String(r.id) !== String(id));
        localStorage.setItem(key, JSON.stringify(filtered));

        const guestKey = 'skillbridge_history_local';
        const guestLocal = JSON.parse(localStorage.getItem(guestKey) || '[]');
        const guestFiltered = guestLocal.filter(r => String(r.id) !== String(id));
        localStorage.setItem(guestKey, JSON.stringify(guestFiltered));
    } catch (e) {}

    // 2. Remove from Java server if running
    try {
        await fetch(`${API_BASE}/api/history?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch (e) {}

    // 3. Remove from Supabase if cloud record
    if (supabaseClient && !isGuestMode && !String(id).startsWith('rec_')) {
        try {
            await supabaseClient.from('learning_history').delete().eq('id', id);
        } catch (e) {
            console.warn('Could not delete from Supabase:', e);
        }
    }

    if (window.__historyRecords) {
        delete window.__historyRecords[String(id)];
    }

    const cardEl = document.getElementById(`history-card-${id}`);
    if (cardEl) {
        cardEl.style.transition = 'all 0.3s ease';
        cardEl.style.opacity = '0';
        cardEl.style.transform = 'scale(0.95)';
        setTimeout(() => {
            loadSavedAnalyses();
        }, 300);
    } else {
        loadSavedAnalyses();
    }

    showToast('Analysis removed from history.', 'success');
}

async function clearAllHistory() {
    if (!confirm('Are you sure you want to clear your entire assessment history? This action cannot be undone.')) return;

    try {
        const key = getUserStorageKey();
        localStorage.removeItem(key);
        localStorage.removeItem('skillbridge_history_local');
    } catch (e) {}

    try {
        await fetch(`${API_BASE}/api/history`, { method: 'DELETE' });
    } catch (e) {}

    window.__historyRecords = {};
    showToast('All history cleared.', 'success');
    loadSavedAnalyses();
}

// ─── AI Career Guide Assistant ───────────────────────────────────────
function setupAssistant() {
    const launcher = document.getElementById('assistant-launcher');
    const closeBtn = document.getElementById('assistant-close');
    const form = document.getElementById('assistant-form');
    const suggestions = document.getElementById('assistant-suggestions');

    launcher?.addEventListener('click', openAssistant);
    closeBtn?.addEventListener('click', closeAssistant);

    form?.addEventListener('submit', (e) => {
        e.preventDefault();
        sendAssistantMessage();
    });

    suggestions?.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-assistant-prompt]');
        if (!btn) return;
        document.getElementById('assistant-input').value = btn.dataset.assistantPrompt;
        sendAssistantMessage();
    });
}

function openAssistant() {
    const panel = document.getElementById('assistant-panel');
    const launcher = document.getElementById('assistant-launcher');
    if (panel) {
        panel.classList.add('open');
        panel.setAttribute('aria-hidden', 'false');
    }
    if (launcher) launcher.setAttribute('aria-expanded', 'true');
    document.getElementById('assistant-input')?.focus();
}

function closeAssistant() {
    const panel = document.getElementById('assistant-panel');
    const launcher = document.getElementById('assistant-launcher');
    if (panel) {
        panel.classList.remove('open');
        panel.setAttribute('aria-hidden', 'true');
    }
    if (launcher) launcher.setAttribute('aria-expanded', 'false');
}

function discussReportWithAI() {
    openAssistant();
    if (!analysisData) return;
    const prompt = `I just received my skill gap report for ${analysisData.desiredJob}. My readiness is ${analysisData.readinessPercent}% with missing skills: ${analysisData.missingSkills.slice(0, 4).join(', ')}. What is the best strategy to master these quickly?`;
    document.getElementById('assistant-input').value = prompt;
    sendAssistantMessage();
}

async function sendAssistantMessage() {
    const input = document.getElementById('assistant-input');
    const message = input.value.trim();
    if (!message || message.length > 1000) return;

    const sendBtn = document.getElementById('assistant-send');
    const messages = document.getElementById('assistant-messages');
    const suggestions = document.getElementById('assistant-suggestions');

    const role = analysisData?.desiredJob || document.getElementById('input-job')?.value || '';
    const skills = analysisData ? [...analysisData.matchedSkills, ...analysisData.missingSkills].join(', ') : (document.getElementById('input-skills')?.value || '');

    appendAssistantMessage(message, 'user');
    input.value = '';
    input.disabled = true;
    if (sendBtn) sendBtn.disabled = true;
    if (suggestions) suggestions.style.display = 'none';

    const typing = appendAssistantMessage('Thinking…', 'ai');

    try {
        const response = await fetch(`${API_BASE}/api/assistant`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message,
                history: assistantHistory.slice(-12),
                role,
                skills
            })
        });

        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'AI mentor did not return a response.');

        typing.textContent = result.reply;
        assistantHistory.push({ role: 'user', text: message });
        assistantHistory.push({ role: 'model', text: result.reply });
    } catch (err) {
        console.error('Assistant error:', err);
        typing.textContent = err.message || 'Unable to connect to AI assistant.';
        typing.classList.add('assistant-message-error');
    } finally {
        input.disabled = false;
        if (sendBtn) sendBtn.disabled = false;
        input.focus();
        messages.scrollTop = messages.scrollHeight;
    }
}

function appendAssistantMessage(text, sender) {
    const messages = document.getElementById('assistant-messages');
    const message = document.createElement('div');
    message.className = `assistant-message assistant-message-${sender}`;
    message.textContent = text;
    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
    return message;
}

// ─── Utilities ────────────────────────────────────────────────────────
function animateNumber(elementId, target, duration = 600) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const startTime = performance.now();
    target = Number(target) || 0;

    function step(now) {
        const progress = Math.min((now - startTime) / duration, 1);
        const easeOut = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(target * easeOut);
        if (progress < 1) {
            requestAnimationFrame(step);
        }
    }
    requestAnimationFrame(step);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'info') {
    document.querySelectorAll('.toast').forEach(t => t.remove());

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            ${type === 'error'
            ? '<circle cx="9" cy="9" r="8" stroke="#f87171" stroke-width="1.5" fill="none"/><path d="M9 5.5v4M9 12.5h.01" stroke="#f87171" stroke-width="1.5" stroke-linecap="round"/>'
            : '<circle cx="9" cy="9" r="8" stroke="#34d399" stroke-width="1.5" fill="none"/><path d="M6 9l2 2 4-4" stroke="#34d399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>'}
        </svg>
        <span>${escapeHtml(message)}</span>
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4500);
}

// ─── Global Window Bindings ──────────────────────────────────────────
window.navigateTo = navigateTo;
window.openAssistant = openAssistant;
window.closeAssistant = closeAssistant;
window.quickStartRole = quickStartRole;
window.nextStep = nextStep;
window.prevStep = prevStep;
window.submitAnalysis = submitAnalysis;
window.resetAnalysis = resetAnalysis;
window.discussReportWithAI = discussReportWithAI;
window.loadAndViewReport = loadAndViewReport;
window.viewHistoryReportById = viewHistoryReportById;
window.deleteHistoryRecord = deleteHistoryRecord;
window.clearAllHistory = clearAllHistory;
window.loadSavedAnalyses = loadSavedAnalyses;
window.filterSavedAnalyses = filterSavedAnalyses;


/**
 * SkillBridge — Supabase & App Configuration
 * 
 * You can put your Supabase credentials here directly,
 * or use the "Configure Supabase" modal on the Sign-In page.
 */
const SKILLBRIDGE_CONFIG = {
    // 1. Paste your Supabase Project URL here (from Project Settings -> API)
    // Example: 'https://xyzabcdefg.supabase.co'
    SUPABASE_URL: 'https://lqqabqnqpgculdufbibn.supabase.co',


    // 2. Paste your Supabase Anon / Publishable Key here (from Project Settings -> API -> anon/public)
    // Example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
    SUPABASE_ANON_KEY: 'sb_publishable_yocBYABVdmd6nt4XZdzjHQ_un8HOLr6'
};

/**
 * Retrieves active Supabase configuration:
 * Prioritizes custom keys saved via the UI settings modal in localStorage,
 * falling back to the hardcoded config above.
 */
function getActiveSupabaseConfig() {
    try {
        const saved = localStorage.getItem('skillbridge_supabase_config');
        if (saved) {
            const parsed = JSON.parse(saved);
            if (parsed.url && parsed.key) {
                return {
                    url: parsed.url.trim().replace(/\/+$/, ''),
                    key: parsed.key.trim(),
                    isCustom: true
                };
            }
        }
    } catch (e) {
        console.warn('Could not read saved Supabase config:', e);
    }

    const defaultUrl = (SKILLBRIDGE_CONFIG.SUPABASE_URL || '').trim().replace(/\/+$/, '');
    const defaultKey = (SKILLBRIDGE_CONFIG.SUPABASE_ANON_KEY || '').trim();

    return {
        url: defaultUrl,
        key: defaultKey,
        isCustom: false
    };
}

/**
 * Creates and returns an initialized Supabase client if valid credentials exist.
 */
function createSupabaseClient() {
    if (!window.supabase) return null;
    const { url, key } = getActiveSupabaseConfig();
    if (!url || !key || !url.startsWith('https://')) return null;

    try {
        return window.supabase.createClient(url, key);
    } catch (e) {
        console.warn('Failed to initialize Supabase client:', e);
        return null;
    }
}

@echo off
echo ================================================
echo  SkillBridge — Light Theme Local Dev Server
echo ================================================
echo.
echo Stopping any old server on port 8080...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8080') do taskkill /f /pid %%a 2>nul
timeout /t 1 >nul

echo Starting server...
cd /d "%~dp0"
start "" "http://localhost:8080/signin.html"
echo.
echo Server running at: http://localhost:8080/signin.html
echo.
echo IMPORTANT: After opening the browser, press Ctrl+Shift+R
echo (or Ctrl+F5) to do a HARD REFRESH and clear the cache!
echo.
echo Press Ctrl+C to stop.
python -m http.server 8080
pause

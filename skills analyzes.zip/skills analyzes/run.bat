@echo off
setlocal

echo ============================================
echo   SkillBridge - Skill Gap Analyser
echo   Building and Starting Server...
echo ============================================
echo.

:: Move to the folder containing this batch file
cd /d "%~dp0"

:: Check for .env here or in parent
if not exist ".env" (
    if exist "..\.env" copy /y "..\.env" ".env" >nul
)

if not exist ".env" (
    echo [ERROR] .env file not found beside run.bat.
    pause
    exit /b 1
)

:: Load the Gemini key from .env
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
    if /i "%%A"=="GEMINI_API_KEY" set "GEMINI_API_KEY=%%B"
)

if not defined GEMINI_API_KEY (
    echo [ERROR] GEMINI_API_KEY was not found in .env.
    pause
    exit /b 1
)

:: Create the build folder if needed
if not exist "build" mkdir build

:: Compile the Java files
echo [1/2] Compiling Java source files...
javac -encoding UTF-8 -d build backend\backend\src\main\java\com\skillgap\SkillGapServer.java backend\backend\src\main\java\com\skillgap\SkillGapAnalyzer.java

if errorlevel 1 (
    echo.
    echo [ERROR] Compilation failed. Check the file paths and that the JDK is installed.
    pause
    exit /b 1
)

:: Start the server & automatically launch browser
echo.
echo [2/2] Starting server...
echo Server running at: http://localhost:8080
echo Opening http://localhost:8080 in your default browser...
echo Keep this window open while using SkillBridge.
echo.

:: Automatically open the browser after a 1.5-second delay to let the server bind
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8080"

:: Start the HTTP server
java -cp build com.skillgap.SkillGapServer

pause
